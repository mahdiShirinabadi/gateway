package com.mahdi.acl;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AclApplicationTests {

	@Test
	void contextLoads() {
	}

}
